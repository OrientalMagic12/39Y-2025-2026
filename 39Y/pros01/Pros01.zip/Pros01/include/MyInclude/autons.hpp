void turnAuton();

void movetest();

void BlueRing_Alliance();


void BlueRingSide();
void BlueGoalSide();
void BlueRingAlt();
void RedRingAlt();
void Redringalt();


void Redringside();
void Redgoalside();

void RedPos6Ring();
void BluePos6Ring();
void BluePosDisrupt();

void RedPosDisrupt();

void RedRing_Alliance();
