
void smartintake();

void ChangeIntakeState(int state, int sort);

void ChangeLiftState(int state, int ins_angle);
void smartlift();

void smartintakeauton();

void drive();

