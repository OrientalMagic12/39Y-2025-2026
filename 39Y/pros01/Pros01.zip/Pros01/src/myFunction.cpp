int get_sign(int input){
    if (input > 0){
        return 1;
    }else if (input < 0){
        return -1;
    }else{
        return 0;
    }
}
