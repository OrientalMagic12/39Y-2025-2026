#ifndef CONFIG_HPP
#define CONFIG_HPP

#include "config.hpp"
#include "pros/motors.hpp"
#include "pros/adi.hpp"
#include "pros/misc.hpp"
#include "main.h"
#include "pros/optical.hpp"

// Motor ports
pros::v5::MotorGroup Right({-12, 13, 14}, pros::MotorGearset::blue);
pros::v5::MotorGroup Left({15, -16, -17}, pros::MotorGearset::blue);

pros::v5::Motor Lift(20);
pros::v5::Motor Lift2(-19);
pros::v5::Motor roller(-10);
pros::v5::Motor hooks(3);
// Sensor ports
//pros::v5::Rotation liftrotation(7);
pros::v5::Imu Gyro(18);
pros::v5::Distance Dis(7);
pros::v5::Optical color(4);
pros::v5::Rotation horizontalencoder(-9);// Yet to declare
pros::v5::Rotation verticalencoder(-8);// Yet to declare

// Pneumatic ports
pros::adi::DigitalOut doinker2('C');
pros::adi::DigitalOut doinker('D');
pros::adi::DigitalOut intakelift('E');
pros::adi::DigitalOut clamp('A');

pros::v5::Controller master(pros::E_CONTROLLER_MASTER);

pros::v5::Optical ColorSensor(5);
//  Controller
// pros::Controller master;
// lemlib::ControllerSettings lateral_controller;
// lemlib::ControllerSettings augular_controller;
// lemlib::Chassis chassis;
// Button 



#endif
