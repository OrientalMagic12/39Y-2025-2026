#include "main.h"
#include "pros/misc.h"

void Randomove() {
    // Get joystick values
    int side = master.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X);
    int line = -master.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);

    int left{};
    int right{};
    if (abs(side) > 12){
        left = line - 0.9 * side;
        right = line + 0.9 * side;
    } else  {
        left = line;
        right = line;
    }

    int leftPower = left > 127 ? get_sign(left) * 127 : left;
    int rightPower = right > 127 ? get_sign(right) * 127 : right;
    // Deadzone check
    if (abs(line) > 12 || abs(side) > 12) {
        Left.move(-leftPower);
        Right.move(-rightPower);
    } else {
        Left.move(0);
        Right.move(0);
    }
}
